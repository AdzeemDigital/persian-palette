import { ALL_PALETTES_LIST, PERSIAN_PALETTES } from './tokens/palettes.js';
import { colorTokenKey, toDTCGToken } from './exporters/w3c.js';
import { VERSION } from './version.js';
import type { PersianColorToken, PersianPaletteTokenGroup } from './types/token.js';
import type { PersianColorDefinition } from './types/palette.js';

/** Normalize Persian/Arabic letter variants, marks, spacing and English case. */
export function normalizeColorName(value: string): string {
  return value
    .normalize('NFKC')
    .toLowerCase()
    .replace(/[\u0649\u064A\u0626]/g, '\u06CC')
    .replace(/\u0643/g, '\u06A9')
    .replace(/[\u06C0\u0629]/g, '\u0647')
    .replace(/[\u0622\u0623\u0625]/g, '\u0627')
    .replace(/[\u064B-\u065F\u0670\u0640]/g, '')
    .replace(/[\u0660-\u0669]/g, d => String(d.charCodeAt(0) - 0x0660))
    .replace(/[\u06F0-\u06F9]/g, d => String(d.charCodeAt(0) - 0x06F0))
    .replace(/[^\p{L}\p{N}]/gu, '');
}
function token(color: PersianColorDefinition): PersianColorToken {
  return { ...toDTCGToken(color), id: color.id, hex: color.hex, nameFa: color.nameFa, nameEn: color.nameEn, evidence: color.evidence };
}
export class PersianEngine {
  static getColor(paletteId: string, name: string): PersianColorToken {
    if (typeof paletteId !== 'string' || !Object.hasOwn(PERSIAN_PALETTES, paletteId))
      throw new RangeError('Unknown palette: ' + paletteId);
    if (typeof name !== 'string' || !normalizeColorName(name)) throw new TypeError('Color query must not be empty');
    const palette = PERSIAN_PALETTES[paletteId], key = normalizeColorName(name);
    const exact = palette.colors.filter(c => [c.id, c.nameEn, colorTokenKey(c), c.nameFa, c.nameFa.replace(/\([^)]*\)/g, '')]
      .some(n => normalizeColorName(n) === key));
    const candidates = exact.length ? exact : palette.colors.filter(c =>
      [c.nameEn, c.nameFa].some(n => normalizeColorName(n).includes(key)));
    if (candidates.length === 0) throw new RangeError('Unknown color: ' + name + ' in ' + paletteId);
    if (candidates.length > 1) throw new RangeError('Ambiguous color: ' + name + '; use a color ID');
    return token(candidates[0]);
  }
  static getToken(paletteId: string, name: string): PersianColorToken { return this.getColor(paletteId, name); }
  static getPalette(paletteId: string): PersianPaletteTokenGroup | undefined {
    if (!Object.hasOwn(PERSIAN_PALETTES, paletteId)) return undefined;
    const p = PERSIAN_PALETTES[paletteId];
    const category = p.category === 'art' || p.category === 'craft' ? 'arts' : p.category;
    return { version: VERSION, id: p.id, nameFa: p.nameFa, nameEn: p.nameEn, category,
      tokens: Object.fromEntries(p.colors.map(c => [colorTokenKey(c), token(c)])), $description: p.descriptionFa };
  }
  static getAllPalettes(): Record<string, PersianPaletteTokenGroup> {
    return Object.fromEntries(ALL_PALETTES_LIST.map(p => [p.id, this.getPalette(p.id)!]));
  }
  static getAllColors(): PersianColorToken[] { return ALL_PALETTES_LIST.flatMap(p => p.colors.map(token)); }
}
